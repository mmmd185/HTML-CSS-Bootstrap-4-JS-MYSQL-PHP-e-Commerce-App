<?php 
$title = 'Dashboard';
include 'header.php';
?>


<?php include 'footer.php';?>